using UnityEngine;

public class BallThrower : MonoBehaviour
{
    public GameObject ballPrefab;
    public Transform spawnPoint;
    public float throwForce = 25f; // Impulse 
    public AudioClip throwSound; // 🎵  
    private AudioSource audioSource;
    void Start()
    {
        audioSource = gameObject.AddComponent<AudioSource>();
    }
    public void ThrowBall()
    {
        GameObject ball = Instantiate(ballPrefab, spawnPoint.position, Quaternion.identity);
        Rigidbody rb = ball.GetComponent<Rigidbody>();

        var cam = Camera.main;
        Vector3 aim = cam.ViewportToWorldPoint(new Vector3(0.5f, 0.5f, cam.nearClipPlane + 0.1f));
        Vector3 direction = (aim - spawnPoint.position).normalized;

        direction = (direction + new Vector3(0.0f, 0.09f, 0.0f)).normalized;
        if (throwSound != null)
        {
            audioSource.PlayOneShot(throwSound);
        }

        rb.AddForce(direction * throwForce, ForceMode.Impulse);
        float mph = Random.Range(90f, 98f);
        float mps = mph / 2.23694f;
        if (SpeedHUD.I) SpeedHUD.I.SetSpeed(mps, true); // 즉시 갱신

    }
}