using UnityEngine;
using UnityEngine.InputSystem; //!

public class PitchSequence : MonoBehaviour
{
    public PitcherAnimator pitcherAnimator;
    public BallThrower ballThrower;

    void Update()
    {
        if (Keyboard.current.spaceKey.wasPressedThisFrame)  // ← New Input System 
        {
        // 🔒 Pitcher  
        pitcherAnimator.transform.rotation = Quaternion.LookRotation(Vector3.forward); // z+  
        StartCoroutine(PitchRoutine());
        }
    }

    private System.Collections.IEnumerator PitchRoutine()
    {
        pitcherAnimator.PlayPitch();
        yield return new WaitForSeconds(1.6f);
        ballThrower.ThrowBall();
    }
    
}