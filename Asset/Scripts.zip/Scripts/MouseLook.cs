using UnityEngine;

public class MouseLook : MonoBehaviour
{
    public float yawSpeed = 60f;  
    public float pitchSpeed = 45f; 
    public float pitchMin = -50f;  
    public float pitchMax = 50f;   

    private float yaw = 0f;
    private float pitch = 0f;

    void Start()
    {
        
        Vector3 angles = transform.eulerAngles;
        yaw = angles.y;
        pitch = angles.x;
    }

    void Update()
    {
        
        float yawInput = 0f;
        if (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow))
            yawInput = -1f;
        else if (Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow))
            yawInput = 1f;

        float pitchInput = 0f;
        if (Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.UpArrow))
            pitchInput = 1f;
        else if (Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.DownArrow))
            pitchInput = -1f;

       
        yaw += yawInput * yawSpeed * Time.deltaTime;
        pitch += pitchInput * pitchSpeed * Time.deltaTime;

       
        pitch = Mathf.Clamp(pitch, pitchMin, pitchMax);

        
        transform.rotation = Quaternion.Euler(pitch, yaw, 0f);
    }
}