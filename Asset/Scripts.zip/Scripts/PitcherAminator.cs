using UnityEngine;

public class PitcherAnimator : MonoBehaviour
{
    private Animator animator;

    void Start()
    {
        animator = GetComponent<Animator>();
        if (animator == null)
        {
            Debug.LogError("❌ Animator component not found on Pitcher!");
        }
    }

    public void PlayPitch()
    {
        Debug.Log("🎯 PlayPitch() called");

        if (animator == null)
        {
            Debug.LogError("❌ Animator is NULL!");
            return;
        }

        animator.SetTrigger("Pitch");
        Debug.Log("✅ Pitch trigger set!");
    }
}