using UnityEngine;
using TMPro;

public class SpeedHUD : MonoBehaviour
{
    public static SpeedHUD I;
    public TextMeshProUGUI label;
    public bool showMph = true;

    float displayed;

    void Awake()
    {
        if (I != null && I != this)
        {
            Destroy(I.gameObject); // 
        }
        I = this;

        if (label == null) label = GetComponentInChildren<TextMeshProUGUI>(true);

        SetSpeed(0f, true);
    }

    void OnDestroy()
    {
        if (I == this) I = null;
    }

    public void SetSpeed(float mps, bool instant = false)
    {
        if (label == null) return;            // 

        float value = showMph ? mps * 2.23694f : mps * 3.6f;
        displayed = instant ? value : Mathf.Lerp(displayed, value, 0.25f);
        label.text = showMph ? $"Speed {displayed:0} mile/h" : $"Speed {displayed:0} km/h";
    }
}